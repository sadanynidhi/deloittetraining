package connectjdbc;
import java.sql.*;

public class Connect {
	
	public static Connection getConnection()
	{
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root";
		String password = "root";
		
		try
		{
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName, userName, password);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
		return conn;
	}

}
