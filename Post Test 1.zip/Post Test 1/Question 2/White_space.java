package test;

import java.util.*;


class White_space 
{
	public static void removeWhiteSpace(String input) 
	{
		StringBuffer in = new StringBuffer(input);
		int word_length = in.length();
		
		for (int i = 0; i < word_length; i++) 
		{
			if (in.charAt(i) == ' ') 
			{  
				in.deleteCharAt(i);
				word_length--;
			}
		}
		System.out.println("The string without white space is: " + in);

	}
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
	  
		System.out.println("Enter String with white space");
		String word = sc.nextLine();
		White_space.removeWhiteSpace(word);
	}
}
