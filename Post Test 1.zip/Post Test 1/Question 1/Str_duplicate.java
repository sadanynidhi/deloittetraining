package test;

import java.util.Scanner;

public class Str_duplicate
{
	
	public static void duplicate(String word) 
	{
		word = word.toLowerCase();
		StringBuffer in = new StringBuffer(word);
		
		int word_length = in.length();
		int count;
		
		for (int i = 0; i < word_length; i++) 
		{
			count = 0;
			
    		for (int j = i + 1; j < word_length; j++) 
    		{
    			if (in.charAt(i) == in.charAt(j)) 
    			{
    		           
    		         in.deleteCharAt(j);
    		         j--;
    		         word_length--;
    		         count++;
    		     }
    		}
    		if(count+1!=1)
    		     System.out.println("Duplicate character is "+in.charAt(i)+" = "+(count+1));
    	}
	}
	public static void main(String[] args) 
	{
		
		System.out.println("Enter any string : ");
		Scanner sc = new Scanner(System.in);
		String word = sc.nextLine();
		Str_duplicate.duplicate(word);

	}
	
}



