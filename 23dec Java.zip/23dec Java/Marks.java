class Marks
{
	
	public static void main(String args[])
	{
		int mark = Integer.parseInt(args[0]);
		if(mark > 50)
			System.out.println("Pass");
		else
			System.out.println("Fail");
	}
}