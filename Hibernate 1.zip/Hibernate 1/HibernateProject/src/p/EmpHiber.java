package p;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction.*;

public class EmpHiber 
{
	public static void main(String[] args)
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		
		Session ses = sf.openSession();
		Transaction ts = ses.beginTransaction();
		ts.begin();
		
		Emp1 e1 = new Emp1();
		e1.setId("4444");
		e1.setEcode("E73");
		e1.setEname("pp");
		
		ses.persist(e1);
		System.out.println("Success");
		ts.commit();
		
	}
}
