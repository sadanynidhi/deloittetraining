package com.example.SpringBoot01.p;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class First {
	@RequestMapping("/v")
	public String show()
	{
		System.out.println("First Boot");
		return "First";
	}
	
	@RequestMapping("/s")
	public String second(@RequestParam("ename")String ename, @RequestParam("salary")String salary, ModelMap m)
	{
		m.put("s1",ename);
		m.put("s2",salary);
		System.out.println("Second Boot");
		return "Second";
	}
}
