document.write("<h1>This is a heading</h1>");
	document.write("<p>This is a paragraph.</p>");