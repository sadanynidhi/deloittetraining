package p;

import java.util.Iterator;
import java.util.List;

public class Quest {
	
	int id;
	String q;
	List<Answers> ans;
	
	public Quest() {}
	
	public Quest(int id, String q, List<Answers> ans) 
	{
		
		this.id = id;
		this.q = q;
		this.ans = ans;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getQ() {
		return q;
	}

	public void setQ(String q) {
		this.q = q;
	}

	public List<Answers> getAns() {
		return ans;
	}

	public void setAns(List<Answers> ans) {
		this.ans = ans;
	}

	void dis()
	{
		System.out.println(id+" "+q+" ");
		Iterator it = ans.iterator();
		System.out.print("ans are:");
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
	
	

}
