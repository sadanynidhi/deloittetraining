package p;

import java.util.Iterator;
import java.util.List;

public class Quest {
	
	int id;
	String q;
	List<Answers> ans;
	
	public Quest(int id, String q, List<Answers> ans) 
	{
		
		this.id = id;
		this.q = q;
		this.ans = ans;
	}
	
	void dis()
	{
		System.out.println(id+" "+q+" ");
		Iterator it = ans.iterator();
		System.out.print("ans are:");
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
	
	

}
