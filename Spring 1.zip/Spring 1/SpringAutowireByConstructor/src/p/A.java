package p;

public class A {
	
	B b1;
	int x,y;
	
	A(B b1,int x)
	{
		this.x = x;
		this.b1 = b1;
	}
	A(B b1)
	{
		this.b1 = b1;
	}
	void dis()
	{
		System.out.println("x = "+x);
		b1.show1();
	}

}
