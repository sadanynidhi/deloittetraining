package p;

import java.util.Iterator;
import java.util.List;

public class Quest {
	
	private int id;
	private String name;
	private List<String> courses;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getCourses() {
		return courses;
	}
	public void setCourses(List<String> courses) {
		this.courses = courses;
	}
	
	void dis()
	{
		System.out.println(id+" "+name+" ");
		Iterator it = courses.iterator();
		System.out.print("courses are:");
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}

}
