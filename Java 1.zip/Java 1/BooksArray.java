class BooksArray
{
	int id;

	public static void main(String args[])
	{	
		int j=0;
		BooksArray b[] = new BooksArray[2];

		for(int i = 0; i <2; i++)
		{
			b[i] = new BooksArray();
		}

		for(int i=0; i<2; i++)
		{
			b[i].id = ++j;
		}
		for(int i=0; i<2; i++)
		{
			System.out.println("id["+i+"] = " + b[i].id);
		}
	}
}