import java.util.*;


class C
{
	int x;
	void show()
	{
		x = 10;
		System.out.println("show()");
		System.out.println("x = "+ x);
	}

	void add(String args1[])
	{
		int a = Integer.parseInt(args1[0]);
		int b = Integer.parseInt(args1[1]);
		System.out.println("Addition of " + a + " and " + b + " is " + (a+b));
	}

	public static void main(String args[])
	{
		System.out.println("Hello");
		C c1 = new C();
		c1.show();

		System.out.println("x in main is "+ c1.x);
	
		c1.add(args);
					 
	}
}