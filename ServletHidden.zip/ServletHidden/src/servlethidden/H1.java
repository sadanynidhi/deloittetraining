package servlethidden;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class H1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			PrintWriter out = response.getWriter();
			String s = request.getParameter("uname");
			String s1 = request.getParameter("password");
			s = s.trim();
			s1 = s1.trim();
			
			if(s.equals("abc") && s1.equals("abc"))
			{
				out.println("Valid user");
				out.println("<html><body>");
				out.println("<form name = 'iii' method = 'get' action = '2'>");
				out.println("<input type = 'hidden' value='"+s+"' name='uname'>");
				out.println("<br><input type='submit' value ='click' name = 'click'>");
				
				out.println("</form>");
				out.println("</body></html>");
			}
			else
			{
				out.println("s="+s+" s1="+s1);
				out.println("Inalid user");
			}
		}
		catch(Exception e) {}
	}

	

}
