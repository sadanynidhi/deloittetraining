
class A
{
	int x;
	A(int p)
	{
		x=p;
	}
	void show()
	{
		System.out.println("x = " + x);
		
	}
}

class ConstructorSingleInherit extends A
{
	
	int y;
	int z;
	
	
	ConstructorSingleInherit() 
	{
		super(30);
		y = 10;
		z = 20;
	}
	
	void show()
	{
		super.show();
		System.out.println("y = " + y);
		System.out.println("z = " + z);
		
	}
	public static void main(String args[])
	{
		ConstructorSingleInherit c = new ConstructorSingleInherit();
		c.show();
		
	}

}
