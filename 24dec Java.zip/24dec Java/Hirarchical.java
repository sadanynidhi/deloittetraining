
class A 
{
	
//	int p;
	void show()
	{
		System.out.println("Super class A");
		
	}

}

class B extends A
{
	
//	int p;
	void show()
	{
		super.show();
		System.out.println("Hirarchical child");
	}

}

class Hirarchical extends A
{
	//int x;
	void show()
	{
		super.show();
		System.out.println("Subclass");
	}
	public static void main(String args[])
	{
		Hirarchical s = new Hirarchical();
		s.show();
		
	}

}
