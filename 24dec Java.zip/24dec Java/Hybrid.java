
class A 
{
	
//	int p;
	void show()
	{
		System.out.println("Supermost class A");
		
	}

}

class B extends A
{
	
//	int p;
	void show()
	{
		super.show();
		System.out.println("Hirarchical child");
	}

}
class C extends A
{
	
//	int p;
	void show()
	{
		super.show();
		System.out.println("Level 1 parent hybrid C");
	}

}


class Hybrid extends C
{
	//int x;
	void show()
	{
		super.show();
		System.out.println("Subclass");
	}
	public static void main(String args[])
	{
		Hybrid s = new Hybrid();
		s.show();
		
	}

}
