import java.util.*;

public class Bank {

	String name;
	int acc_no;
	String type;
	double balance;
	
	Bank()
	{
		name = "abc";
		acc_no = 0;
		type = "savings";
		balance = 0.0;
		
	}
	
	void deposit()
	{
		System.out.println("Enter amount to be deposited:");
		Scanner sc = new Scanner(System.in);
		int deposit = sc.nextInt();
		balance = deposit + balance;
		System.out.println("New Balance is "+balance);
	}
	
	void withdraw()
	{
		System.out.println("Available Balance = "+balance);
		System.out.println("Enter amount to be withdrawn:");
		Scanner sc = new Scanner(System.in);
		int withdraw = sc.nextInt();
		
		if(withdraw > balance)
		{
			System.out.println("Insufficient Balance");

		}
		else
		{
			balance = balance - withdraw;
		}
		System.out.println("Amount "+withdraw+" has been debited.");
		System.out.println("Available balance is : "+balance);


	}
	
	void display()
	{
		System.out.println("Name of account holder : "+name);
		System.out.println("Balance in account : "+balance);

	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bank b1 = new Bank();
		System.out.println("Enter name of account holder:");
		Scanner sc = new Scanner(System.in);
		b1.name = sc.nextLine();
		
		System.out.println("Enter type of account:");
		b1.type = sc.nextLine();
		
		System.out.println("Enter account number:");
		b1.acc_no = sc.nextInt();
		
		System.out.println("Enter initial balance of account:");
		b1.balance = sc.nextInt();
		
		b1.deposit();
		b1.withdraw();
		b1.display();
		
		sc.close();

	}

}
