import java.util.*;

public class Books {

	String author;
	String title;
	double price;
	String publisher;
	int stock_position;
	
	public Books(String author, String title, double price, String publisher, int stock_position) {
		super();
		this.author = author;
		this.title = title;
		this.price = price;
		this.publisher = publisher;
		this.stock_position = stock_position;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Books b[] = new Books[2];
		
		b[0] = new Books("Dan brown","Angels and demons",500,"blueberry",5);
		b[1] = new Books("Jk rowling","harry pottter",200,"blueberry",10);
		
		System.out.println("Enter book title to search:");
		Scanner sc = new Scanner(System.in);
		String name = sc.nextLine();
		System.out.println("Enter author to search:");
		String a_name = sc.nextLine();
		int flag = 0;
		for(int i = 0; i<2; i++)
		{
			if(b[i].title.equalsIgnoreCase(name) && b[i].author.equalsIgnoreCase(a_name))
			{
				System.out.println("Book name: " +b[i].title);
				System.out.println("Book author name: " +b[i].author);
				System.out.println("Book price: " +b[i].price);
				System.out.println("Book publisher name: " +b[i].publisher);
				
				System.out.println("Enter number of copies required:");
				int count = sc.nextInt();
				if(count>b[i].stock_position)
				{
					System.out.println("Required copies not in stock.");
				}
				else
				{
					double total = count * b[i].price;
					System.out.println("Total cost of "+count+" books is "+total);
				}
				flag = 1;
				break;

			}
			
		}
		if(flag == 0)
		{
			
			System.out.println("Book not available");
		}

	}

}
