
class A {
	
//	int p;
	void show()
	{
		System.out.println("Super class");
	}

}

class SingleInheritance extends A
{
	//int x;
	void show()
	{
		super.show();
		System.out.println("Subclass");
	}
	public static void main(String args[])
	{
		SingleInheritance s = new SingleInheritance();
		s.show();
		
	}

}
