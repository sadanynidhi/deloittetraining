
class A
{
	int x;
	
	void show()
	{
		System.out.println("x = " + x);
		
	}
}

class DynamicPoly extends A
{
	
	int y;
	int z;
	
	
	DynamicPoly() 
	{
		
		y = 10;
		z = 20;
	}
	
	void show()
	{
		
		System.out.println("y = " + y);
		System.out.println("z = " + z);
		
	}
	public static void main(String args[])
	{
		A a1 = new DynamicPoly();
		a1.show();
		
	}

}
