
public class ConstructorDemo {
	
	int x;
	static int p;
	
	
	ConstructorDemo(int x) {
		this.x = x;
	}
	
	ConstructorDemo()
	{
		x=20;
	}
	
	void show()
	{
		System.out.println(x);
	}
	public static void main(String args[])
	{
		ConstructorDemo c = new ConstructorDemo();
		c.show();
		ConstructorDemo c1 = new ConstructorDemo(30);
		c1.show();
	}

}
