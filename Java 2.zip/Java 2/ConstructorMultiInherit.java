
class A
{
	int x;
	A(int p)
	{
		x=p;
	}
	void show()
	{
		System.out.println("x = " + x);
		
	}
}
class B extends A
{
	int a;
	B(int p)
	{
		super(40);
		a=p;
	}
	void show()
	{
		super.show();
		System.out.println("a = " + a);
		
	}
}

class ConstructorMultiInherit extends B
{
	
	int y;
	int z;
	
	
	ConstructorMultiInherit() 
	{
		super(30);
		y = 10;
		z = 20;
	}
	
	void show()
	{
		super.show();
		System.out.println("y = " + y);
		System.out.println("z = " + z);
		
	}
	public static void main(String args[])
	{
		ConstructorMultiInherit c = new ConstructorMultiInherit();
		c.show();
		
	}

}
