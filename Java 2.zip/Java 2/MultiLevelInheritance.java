
class A 
{
	
//	int p;
	void show()
	{
		System.out.println("Super class A");
		
	}

}

class B extends A
{
	
//	int p;
	void show()
	{
		super.show();
		System.out.println("Super class B");
	}

}

class MultiLevelInheritance extends B
{
	//int x;
	void show()
	{
		super.show();
		System.out.println("Subclass");
	}
	public static void main(String args[])
	{
		MultiLevelInheritance s = new MultiLevelInheritance();
		s.show();
		
	}

}
