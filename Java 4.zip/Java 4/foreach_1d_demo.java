public class foreach_1d_demo {

	public static void main(String[] args) {
		int b[] = {1,2,3,4} ;
		for(int i : b)
		{
			System.out.println(i);
		}

		
	}

}
