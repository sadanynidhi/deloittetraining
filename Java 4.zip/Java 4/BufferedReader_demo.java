import java.io.*;

public class BufferedReader_demo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int i;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter your name");
		System.out.println("Name : "+br.readLine());
	}

}
