import java.io.*;
class DIOS {
	public static void main(String arg[])throws IOException
	{
		FileOutputStream f= new FileOutputStream("primitive.txt");
		DataOutputStream d=new DataOutputStream(f);
		d.writeBoolean(true);
		d.writeInt(10);
		d.writeChar('s');
		d.writeFloat((float)100.23);
		d.writeByte(12);
		d.close();
		FileInputStream fi= new FileInputStream("primitive.txt");
		DataInputStream di=new DataInputStream(fi);
		boolean b=di.readBoolean();
		char c= di.readChar();
		int i=di.readInt();
		float fl=di.readFloat();
		byte by=di.readByte();
		
		System.out.println(b);
		System.out.println(c);
		System.out.println(i);
		System.out.println(fl);
		System.out.println(by);
		di.close();
	}
}
