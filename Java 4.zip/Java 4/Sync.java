class Demo1111 implements Runnable
{
	public void run()
	{
		show();
	}
	synchronized void show()
	{
		System.out.println("Hello");
		try
		{
			Thread.sleep(1000);
		}
		catch(Exception e)
		{
			System.out.println("Exception");
		}
		System.out.println("Bye");
	}
}
public class Sync {

	public static void main(String[] args) {
		Demo1111 d = new Demo1111();
		Demo1111 d1 = new Demo1111();
		Thread t = new Thread(d);
		Thread t1 = new Thread(d);
		t.start();
		t1.start();
		

	}

}
