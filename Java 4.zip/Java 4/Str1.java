
public class Str1 {
	public static void main(String args[])
	{
		String s1="Hello";
		String s2 = "World";
		String s = new String();
		s = s1;
		if(s.contentEquals(s1))
			System.out.println("s == s1");
		else
			System.out.println("s != s1");
		if(s.contentEquals(s2))
			System.out.println("s == s2");
		else
			System.out.println("s != s2");
		s = s2;
		if(s.contentEquals(s2))
			System.out.println("s == s2");
		else
			System.out.println("s != s2");
		if(s.contentEquals(s1))
			System.out.println("s == s1");
		else
			System.out.println("s != s1");
	}
}
