import java.io.*;

public class FIS {
	int i;
	FileInputStream f;
	
	void read_func()
	{
		
		try
		{
			f = new FileInputStream("1.txt");
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Exception");
		}
		
		try
		{
			do
			{
				i=f.read();
				if(i!=-1)
					System.out.println((char)i);
			}while(i!=-1);
			
		}
		catch(IOException e)
		{
			System.out.println("Exception");
		}
		

	}

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		FIS f = new FIS();
		f.read_func();
		
	}

}

