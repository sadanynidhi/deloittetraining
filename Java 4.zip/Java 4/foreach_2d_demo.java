public class foreach_2d_demo {

	public static void main(String[] args) {

		int x[][]= {{1,2,3},{2,3,4},{3,4,5}};
		
		for(int i = 0; i<3;i++)
		{
			for(int j=0; j<3;j++)
			{
				System.out.println(x[i][j]);
			}
		}
		
		for(int i[]:x)
		{
			for(int p:i)
					System.out.println("p="+p);
		}
		
	}

}
