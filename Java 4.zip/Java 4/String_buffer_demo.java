
public class String_buffer_demo {

	public static void main(String[] args) {
		String s = "hello";
		String s1 = "hello";
		String s2 = new String("hello");
		String s3 = new String("hello");
		
		StringBuffer sb = new StringBuffer("hello world");
		sb = sb.delete(4, 8);
		System.out.println("after del"+sb);
		sb = sb.append(s);
		System.out.println(sb);
		System.out.println(s==s1);
		System.out.println(s.equals(s1));
		System.out.println(s2==s3);
		System.out.println(s2.equals(s3));
		System.out.println(s2==s1);
		System.out.println(s2.equals(s1));
		System.out.println(s2.equals(s));
		System.out.println("another class"+s.equals(Str1.s1));
		
	}

}

class Str1
{
	static String s1="hello";
}

