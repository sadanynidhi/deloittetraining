
import java.io.*;

class FOS2
{
	int i;
	FileInputStream f;
	FileOutputStream fo;
	
	void read_write()
	{
		try
		{
			String s = "i  m fine";
			byte b[] = s.getBytes();
			
			//byte b1[]= {90,23};
			
			fo = new FileOutputStream("fine1.txt");
			f = new FileInputStream("fine1.txt");
			
			fo.write(b);
			
			//fo.flush();
			fo.close();
			
			do
			{
				i=f.read();
				if(i!=-1)
				{
					System.out.println((char)i);
				}
			}while(i!=-1);
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}



	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		FOS2 f = new FOS2();
		f.read_write();
		

	}
}

