class A 
{
	void s()
	{
		System.out.println("Hello");
		try{
			Thread.sleep(1000);
			}
		catch(InterruptedException e)
		{
		System.out.println("Child Thread Interrupted hello");
			}
		System.out.println("Tata");
	}
	void s2()
	{
	System.out.println("s2");
	}
}
class Demo implements Runnable{
	int i;
	A a;
	Demo(A a)
	{
		this.a=a;
	}
	public void run()
	{
		synchronized(a)
		{
			a.s();
		}	
	}
}
class DemoThread1
{
	public static void main (String arg[])
	{
		A a1=new A();
		Demo d= new Demo(a1);
		Thread t,t1;
		t=new Thread(d);
		t.start();
		t1=new Thread(d,"two");
		t1.start();
		
	}
}