package p;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class A1 {
	
	public static void main(String[] args)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		OP e = (OP) context.getBean("Opbean");
		System.out.println("calling msg...");
		e.msg();
		
		System.out.println("calling m...");
		e.m();
		System.out.println("calling k...");
		e.k();
	}

}
