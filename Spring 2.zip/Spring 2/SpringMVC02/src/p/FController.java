package p;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FController 
{
	@RequestMapping("/v1")
	public String show()
	{
		System.out.println("welcome to first page");
		return "First";
	}
	
	@RequestMapping("/v2")
	public String show1()
	{
		System.out.println("welcome to second page");
		return "Second";
	}
	
	
}
