package p;

public class Emp {
	
	String ename;
	int salary;
	
	public Emp() {}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public Emp(String ename, int salary) {
		super();
		this.ename = ename;
		this.salary = salary;
	}
	
	
	

}
