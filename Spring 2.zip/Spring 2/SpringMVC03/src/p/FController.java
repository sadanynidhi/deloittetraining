package p;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FController 
{
	@RequestMapping("/v")
	public String dis(HttpServletRequest req, Model m)
	{
		System.out.println("hello");
		String en = req.getParameter("ename");
		String sa = req.getParameter("salary");
		m.addAttribute("s1",en);
		m.addAttribute("s2", sa);
		return "First";
	}
	
	//or
	/*@RequestMapping("/v")
	public String dis(HttpServletRequest req, ModelMap m)
	{
		System.out.println("hello");
		String en = req.getParameter("ename");
		String sa = req.getParameter("salary");
		m.put("s1",en);
		m.put("s2",sa);
		return "First";
	}*/
	
}
