package p;
import java.sql.*;
public class Select_demo {
	
	void show()
	{
		System.out.println("Mysql connect example");
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root";
		String password = "root";
		
		try
		{
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName, userName, password);
			Statement sm = conn.createStatement();
			//String s1 = "abc";
		//	String s = "e001";
			ResultSet rs = sm.executeQuery("select * from emp");
			System.out.println("Connected");
			while(rs.next())
			{
				String f = rs.getString(1);
				String f1 = rs.getString(2);
				System.out.println(f);
				System.out.println(f1);
				
			}
			conn.close();
			System.out.println("Disconnected");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args)
	{
		Select_demo s1 = new Select_demo();
		s1.show();
	}

}
