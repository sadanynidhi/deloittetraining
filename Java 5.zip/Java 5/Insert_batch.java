package p;
import java.sql.*;
import java.util.Scanner;
public class Insert_batch {
	
	void show()
	{
		System.out.println("Mysql connect example");
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root";
		String password = "root";
		
		try
		{
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName, userName, password);
			
			PreparedStatement ps = conn.prepareStatement("insert into emp values(?,?)");
			conn.setAutoCommit(false);
			
			String ans = "yes";
			do
			{
				System.out.println("Give ecode: ");
				Scanner sc = new Scanner(System.in);
				String s = sc.nextLine();
				
				System.out.println("Give ename: ");
				String s1 = sc.nextLine();
				
				ps.setString(1, s);
				ps.setString(2, s1);
				
				ps.addBatch();
				
				System.out.println("Do you want to insert more rows? (yes/no)");
				ans = sc.nextLine();
				//sc.close();
			}while(ans.equals("yes"));
			
			int x[] = ps.executeBatch();
			for(int i:x)
			{
				System.out.println(""+i+" record inserted");
			}
			conn.commit();
			
			conn.close();
			System.out.println("Disconnected");
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args)
	{
		Insert_batch s1 = new Insert_batch();
		s1.show();
	}

}
