package p;
import java.sql.*;
import java.util.Scanner;
public class Update_batch {
	
	void show()
	{
		System.out.println("Mysql connect example");
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root";
		String password = "root";
		
		try
		{
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName, userName, password);
			
			PreparedStatement ps = conn.prepareStatement("update emp set ename=? where ecode=?");
			conn.setAutoCommit(false);
			String ans = "yes";
			do
			{
				System.out.println("Give ename to set: ");
				Scanner sc = new Scanner(System.in);
				String s = sc.next();
				
				System.out.println("Give ecode of which ename is to be changed: ");
				String s1 = sc.next();
				
				ps.setString(1, s);
				ps.setString(2, s1);
				ps.addBatch();
				
				System.out.println("Do you want to update more rows? (yes/no)");
				ans = sc.next();
				//sc.close();
			}while(ans.equals("yes"));
			
			
			int x[] = ps.executeBatch();
			for(int i:x)
			{
				System.out.println(""+i+" record updated");
			}
			conn.commit();
			
			
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args)
	{
		Update_batch s1 = new Update_batch();
		s1.show();
	}

}
