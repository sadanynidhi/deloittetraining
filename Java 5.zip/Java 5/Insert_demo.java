package p;
import java.sql.*;
import java.util.Scanner;
public class Insert_demo {
	
	void show()
	{
		System.out.println("Mysql connect example");
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root";
		String password = "root";
		
		try
		{
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName, userName, password);
			
			PreparedStatement ps = conn.prepareStatement("insert into emp values(?,?)");
			
			System.out.println("Give ecode: ");
			Scanner sc = new Scanner(System.in);
			String s = sc.nextLine();
			
			System.out.println("Give ename: ");
			String s1 = sc.nextLine();
			
			ps.setString(1, s);
			ps.setString(2, s1);
			
			System.out.println("Connected");
			int x = ps.executeUpdate();
			System.out.println(""+x+" record inserted");
			
			conn.close();
			System.out.println("Disconnected");
			sc.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args)
	{
		Insert_demo s1 = new Insert_demo();
		s1.show();
	}

}
