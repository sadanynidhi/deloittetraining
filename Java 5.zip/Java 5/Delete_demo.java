package p;
import java.sql.*;
import java.util.Scanner;
public class Delete_demo {
	
	void show()
	{
		System.out.println("Mysql connect example");
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root";
		String password = "root";
		
		try
		{
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName, userName, password);
			
			PreparedStatement ps = conn.prepareStatement("delete from emp where ecode=?");
			
			System.out.println("Give ecode to be deleted: ");
			Scanner sc = new Scanner(System.in);
			String s = sc.nextLine();
			
			
			ps.setString(1, s);
			
			System.out.println("Connected");
			int x = ps.executeUpdate();
			System.out.println(""+x+" record deleted");
			
			conn.close();
			System.out.println("Disconnected");
			sc.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args)
	{
		Delete_demo s1 = new Delete_demo();
		s1.show();
	}

}
