package jdbcservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class JDBCservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
	{
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root";
		String password = "root";
		
		try
		{
			PrintWriter out = response.getWriter();
			String s = request.getParameter("ename");
			out.print("s = "+s);
			out.print("MySql connect example.");
			
			try 
			{
				Class.forName(driver);
				conn = DriverManager.getConnection(url+dbName, userName, password);
				Statement sm = conn.createStatement();
				ResultSet rs = sm.executeQuery("select * from emp");
				//System.out.println("Connected");
				out.print("Connected");
				
				out.print("<table border = 1 bgcolor = lightblue>");
				out.print("<th>ECODE</th><th> ENAME</th>");
				while(rs.next())
				{
					String f = rs.getString(1);
					String f1 = rs.getString(2);
					out.print("ename ="+f1);
					out.print("<tr><td>"+f+"</td><td>"+f1+"</td></tr>");
					
				}
				out.println("</table>");
				conn.close();
				out.print("Disconnected from database");
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		
		catch(IOException e)
		{
			System.out.println(e);
		}
	}

}
