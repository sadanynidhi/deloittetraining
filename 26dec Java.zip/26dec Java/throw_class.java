class throw_class
{
	int x,y,z;
	void div() throws InterruptedException 
	{	
		Thread.sleep(-1); 
		throw new IllegalArgumentException();
		
		
	}
	public static void main(String args[])
	{
		throw_class b1 = new throw_class();
		try
		{
			b1.div();
		}
		
		catch(IllegalArgumentException e)
		{
			System.out.println("Exception is IllegalArgumentException");
		}
		catch(InterruptedException e) 
		{
			
			e.printStackTrace();
		}
		finally
		{
			System.out.println("finally");
		}
		
	}
}