abstract class abstractClass
{
	abstract void show();
}
class subClass extends abstractClass
{
	void show()
	{
		System.out.println("Sub class");
	}
	
}
class sibling_child extends abstractClass
{
	void show()
	{
		System.out.println("sibling child");
	}
	public static void main(String args[])
	{
		abstractClass a = new sibling_child();
		a.show();
	}
}