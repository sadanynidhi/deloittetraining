class try_multi_catch
{
	int x,y,z;
	void div()
	{	
		try
		{	z=0;
			int a[] = new int[2];
			x= a[3]/z;
			System.out.println(x);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array out of bound");
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
	}
	public static void main(String args[])
	{
		try_multi_catch b1 = new try_multi_catch();
		b1.div();
	}
}