class MyException extends Exception 
{ 
    public String toString()
    { 
         return "Divide by 7 not allowed";
    } 
} 

class custom_exception
{
	
	
	public static void main(String args[])
	{
		custom_exception b1 = new custom_exception();
		try
		{
			int x = 2;
			int y=9;
			int z=7;
			x=y/z;
			if(z==7)
			{
				throw new MyException();
			}
		}
		catch(MyException e)
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			System.out.println("finally");
		}
		
	}
}