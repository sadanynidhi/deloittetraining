class finally_class
{
	int x,y,z;
	void div()
	{	
		try
		{	z=0;
			int a[] = new int[2];
			x= a[3]/z;
			System.out.println(x);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array out of bound");
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		finally
		{
			System.out.println("finally");
		}
	}
	public static void main(String args[])
	{
		finally_class b1 = new finally_class();
		b1.div();
	}
}