interface interfaceDemo_inherit
{
	void show();
}
interface int_second
{
	void dis();
}
class int_class implements interfaceDemo_inherit, int_second
{
	public void show()
	{
		System.out.println("Class B implements Interface 1");
	}
	public void dis()
	{
		System.out.println("Class B implements Interface 2");
	}
	public static void main(String args[])
	{
		int_class b1 = new int_class();
		b1.show();
		b1.dis();
	}
}