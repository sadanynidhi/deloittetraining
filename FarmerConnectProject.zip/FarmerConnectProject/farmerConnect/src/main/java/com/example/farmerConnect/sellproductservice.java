package com.example.farmerConnect;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class sellproductservice {
	@Autowired
	sellproductrepository sprepo;
	
	
	public sellproduct getsellproduct(int sellid) {
		return sprepo.findById(sellid).get();
	}
	
	public Boolean getId(int id) {
		return sprepo.findById(id).isPresent();
	}
	
	
	public void savesellproduct(sellproduct ct)
	{
		sprepo.save(ct);
	}
	
	public void deleteProduct(int sellid)
	{
		sprepo.deleteById(sellid);
	}
	
	
}
