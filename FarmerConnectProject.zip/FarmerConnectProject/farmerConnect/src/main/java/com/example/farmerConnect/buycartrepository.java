package com.example.farmerConnect;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface buycartrepository extends JpaRepository<buycart,String>{
	List<buycart> findBytranzid(String tranzid);
}
