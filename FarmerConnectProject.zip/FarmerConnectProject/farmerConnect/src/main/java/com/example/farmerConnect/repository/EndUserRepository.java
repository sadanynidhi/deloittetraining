package com.example.farmerConnect.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.farmerConnect.pojo.EndUser;

public interface EndUserRepository extends JpaRepository<EndUser, Integer> {
	EndUser findByEmailAndPassword(String email,String password);

}
