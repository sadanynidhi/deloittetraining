package com.example.farmerConnect;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class cartservice {
	@Autowired
	buycartrepository bcr;
	
	
	public List<buycart> getcartproducts() {
		return bcr.findAll();
	}
	
}
