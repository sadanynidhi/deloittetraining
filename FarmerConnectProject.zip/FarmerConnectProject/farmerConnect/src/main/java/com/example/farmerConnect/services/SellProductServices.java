package com.example.farmerConnect.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.farmerConnect.dao.SellProductDao;
import com.example.farmerConnect.pojo.SellProduct;

@Service
public class SellProductServices {
	
	@Autowired
	SellProductDao Dao;
	List<SellProduct> endUser;
	
	public List<SellProduct> getData()
	{
		return Dao.listAll();
	}
	public void addSellProduct(SellProduct eu)
	{
		Dao.saveSellProduct(eu);
	}
	
	public SellProduct findSellProduct(int id)
	{
		
		SellProduct endUser1 = Dao.getId(id);
		return endUser1;
	}
	
	public List<SellProduct> deleteEndUser(int id)
	{
		Dao.deleteSellProduct(id);
		endUser=getData();
		return endUser;
	}

}
