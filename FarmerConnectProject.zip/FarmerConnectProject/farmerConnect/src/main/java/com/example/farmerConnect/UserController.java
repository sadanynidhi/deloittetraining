package com.example.farmerConnect;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;



@Controller
public class UserController {
	
	@Autowired
	UserService us;
	@Autowired
	sellproductservice spr;
	
	@Autowired
	sellproductrepository sprepo;

	@Autowired
	buycartrepository buyrepo;

	
	@RequestMapping("/")
	public String view() {
		System.out.println("welcome");
		return "welcome";
	}
	
	@RequestMapping("/login")
	public String login() {
		System.out.println("Login");
		return "login";
	}
	
	@RequestMapping("/register")
	public String register() {
		System.out.println("Register");
		return "register";
	}
	
	//from login page
	@RequestMapping("/1")
	public String view1(HttpServletRequest req,@RequestParam("email")String email, @RequestParam("password")String password, Model m) 
	{
		if(us.getId(email)&&us.getUser(email).getPassword().equals(password)) {
			HttpSession ses = req.getSession(true);
			ses.setAttribute("un",email);
			
			System.out.println("un="+email);
			String un=(String) req.getSession().getAttribute("un");
			System.out.println("un="+un);
			
			return "dashboard";
		}
		else {
		return "login";}	
	}
	
	//not part of project
	@RequestMapping("/2")
	public String view2(HttpServletRequest req, Model m) {
		HttpSession ses = req.getSession(false);
		String s=(String)ses.getAttribute("un");
		System.out.println("S="+s);
		m.addAttribute("s",s);
		return "Fourth";
		
	}
	
	//for register page
	@RequestMapping("/3")
	public String view3(Model m) {
		User u = new User();
		m.addAttribute("UserObj",u);
		return "NewUser";
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String saveNewContact(@ModelAttribute("UserObj") User UserObj)
	{
		us.saveUser(UserObj);
		
		return "redirect:/"; // goes to welcome page
		//return "NewFile";//it's working 
	}
	
	
	//to save/edit product
	@RequestMapping(value="/saveproduct",method=RequestMethod.POST)
	public String saveproduct(@ModelAttribute("sellObj") sellproduct sellObj, HttpServletRequest req,Model m)
	{
		String email=(String) req.getSession().getAttribute("un");
		System.out.println(email);
		sellObj.setEmail(email);
		spr.savesellproduct(sellObj);
		
		//to display history table
		System.out.println(email);
		List<sellproduct> tp=sprepo.findByemail(email);
		m.addAttribute("history",tp);
		System.out.println(tp);
		return "sellhistory";
		//return "NewFile";//it's working 
	}
	
	//from sellhistory page //to add more products
	@RequestMapping("/sell2")
	public String sellsaveobj(HttpServletRequest req,Model m) 
	{
		String email=(String) req.getSession().getAttribute("un");
		System.out.println(email);
		
		sellproduct u = new sellproduct();
		u.setEmail(email);
		m.addAttribute("sellObj",u);
		
		
		//m.addAttribute("un",email);
		return "sell";
	}
	
	//from dashboard //to view seller history
	@RequestMapping("/sell1")
	public String showSellHistory(HttpServletRequest req,Model m)
	{
		String email=(String) req.getSession().getAttribute("un");
		System.out.println(email);
		
		List<sellproduct> tp=sprepo.findByemail(email);
		m.addAttribute("history",tp);
		System.out.println(tp);
		
		return "sellhistory";
	}
	
	@RequestMapping(value="/edit/{sellid}")
	public ModelAndView showEditProductPage(@PathVariable(name="sellid") int sellid,HttpServletRequest req,Model m) //for edit record
	{
		String email=(String) req.getSession().getAttribute("un");
		System.out.println(email);
		
		ModelAndView mv=new ModelAndView("EditProduct");
		sellproduct cnt=spr.getsellproduct(sellid);
		mv.addObject("ProductEditObj",cnt);
		
		return mv;
	}
	
	@RequestMapping(value="/delete/{sellid}")
	public String DeleteProduct(@PathVariable(name="sellid")int sellid,  HttpServletRequest req,Model m)
	{
		
		spr.deleteProduct(sellid);
		
		//to display history table
		String email=(String) req.getSession().getAttribute("un");
		System.out.println(email);
		
		List<sellproduct> tp=sprepo.findByemail(email);
		m.addAttribute("history",tp);
		System.out.println(tp);
		
		return "sellhistory";
		
	}

	//buy
	
	@RequestMapping("/buy1")
	public String buy11() {
		System.out.println("First");
		return "buy";
	}
	
	@RequestMapping("/buy2")
	public String buy2(@RequestParam("name")String name,Model m) {
		System.out.println(name);
		List<sellproduct> tp=sprepo.findByname(name);
		m.addAttribute("buyprodlist",tp);
		System.out.println(tp);
		return "buy";
	}
	
	@RequestMapping(value="/addcart/{sellid}")
	public String AddToCart(@PathVariable(name="sellid")int sellid,HttpSession ses, HttpServletRequest req,Model m)
	{
		System.out.println("in cart");
		sellproduct p = sprepo.findBysellid(sellid);
		buycart c1=new buycart();
		c1.setTranzid(ses.getId());
		c1.setSellid(p.getSellid());
		c1.setEmail(p.getEmail());
		c1.setName(p.getName());
		c1.setPrice(p.getPrice());
		c1.setQuantity(p.getQuantity());
		System.out.println("Care"+c1);
		buyrepo.save(c1);
		return "buy";
	}
	@RequestMapping(value="/savetobuycart",method=RequestMethod.POST)
	public String savetobuycart( HttpServletRequest req,HttpSession ses,Model m)
	{
		System.out.println("in cart");
		String email=(String) req.getSession().getAttribute("un");
		sellproduct p1=(sellproduct)req.getSession().getAttribute("p1");
		buycart c1=new buycart();
		c1.setTranzid(ses.getId());
		c1.setSellid(p1.getSellid());
		c1.setEmail(p1.getEmail());
		c1.setName(p1.getName());
		c1.setPrice(p1.getPrice());
		c1.setQuantity(p1.getQuantity());
		System.out.println("Care"+c1);
		buyrepo.save(c1);
		return "buy";
	}
	
	//cart
	@RequestMapping("/cart1")
	public String cart(HttpServletRequest req,HttpSession ses,Model m) {
		System.out.println("cart");
		double total=0;
		buycart bc = new buycart();
		String tz = ses.getId();
		List <buycart> bycart=buyrepo.findBytranzid(tz);
		Iterator<buycart> iterator = bycart.iterator();
		iterator = bycart.iterator();
		while(iterator.hasNext()){
			buycart x = (buycart) iterator.next();
			double a=x.getPrice()*x.getQuantity();
			total=total+a;
			
		}
		m.addAttribute("total",total);
	
		//req.getSession().setAttribute("cartlist", bycart);
		m.addAttribute("cartlist",bycart);
		return "cart";
	}
	
	@RequestMapping(value = "/logout")
	public String logout(HttpServletRequest request) {
	    HttpSession session = request.getSession(false);
	    if (session != null) {
	        session.invalidate();
	    }
	    return "redirect:/";  
	}

	@RequestMapping(value = "/dash")
	public String dash() {
	  
	    return "dashboard";  
	}
	
	@RequestMapping(value = "/ordersubmit1")
	public String ordersubmit1() {
	  
	    return "ordersubmit";  
	}

}
