package com.example.farmerConnect.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.farmerConnect.pojo.SellProduct;
import com.example.farmerConnect.repository.SellProductRepository;
@Service
public class SellProductDao {

	@Autowired
	SellProductRepository repo;
	
	public List<SellProduct> listAll()
	{
		return repo.findAll();
	}
	public SellProduct getId(Integer id)
	{
		return repo.findById(id).get();
	}
	public void saveSellProduct(SellProduct eu)
	{
		repo.save(eu);
	}
	public void deleteSellProduct(int id)
	{
		repo.deleteById(id);
	}
}
