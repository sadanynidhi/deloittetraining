package com.example.farmerConnect;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class buycart {
	private int key1;
	
	private String tranzid;
	private int sellid;
	private int quantity;
	String email,name;
	double price;
	public buycart() {
		super();
	}
	
	@Id
	public int getKey1() {
		return key1;
	}


	public void setKey1(int key1) {
		this.key1 = key1;
	}
	public String getTranzid() {
		return tranzid;
	}
	public void setTranzid(String tranzid) {
		this.tranzid = tranzid;
	}
	public int getSellid() {
		return sellid;
	}
	public void setSellid(int sellid) {
		this.sellid = sellid;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
}
