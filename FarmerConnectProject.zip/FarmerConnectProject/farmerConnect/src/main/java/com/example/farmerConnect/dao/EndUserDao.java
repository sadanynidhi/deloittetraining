package com.example.farmerConnect.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.farmerConnect.pojo.EndUser;
import com.example.farmerConnect.repository.EndUserRepository;
@Service
public class EndUserDao {
	@Autowired
	EndUserRepository repo;

	public List<EndUser> listAll()
	{
		return repo.findAll();
	}
	public EndUser getId(Integer id)
	{
		return repo.findById(id).get();
	}
	public void saveEndUser(EndUser eu)
	{
		repo.save(eu);
	}
	public void deleteEndUser(int id)
	{
		repo.deleteById(id);
	}
}
