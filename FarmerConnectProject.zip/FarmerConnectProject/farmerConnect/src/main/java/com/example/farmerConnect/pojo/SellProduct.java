package com.example.farmerConnect.pojo;

import java.io.File;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
@Entity
public class SellProduct {
	
	
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "BOOT_USER_SEQ")
	@SequenceGenerator(sequenceName = "customer_seq",allocationSize = 1,name = "BOOT_USER_SEQ")
	private int sellOrderId;
	private int sellerUserId;
	private String category,name,sellerLocation;
	File image;
	double price,quantity;
	Date date;
	
	
	
	public SellProduct(int sellerUserId, String category, String name, String sellerLocation, File image,
			double price, double quantity) {
		super();
		this.sellerUserId = sellerUserId;
		this.category = category;
		this.name = name;
		this.sellerLocation = sellerLocation;
		this.image = image;
		this.price = price;
		this.quantity = quantity;
		this.date = new Date();
	}
	public SellProduct() {
		super();
	}
	
	@Id
	public int getSellOrderId() {
		return sellOrderId;
	}
	public void setSellOrderId(int sellOrderId) {
		this.sellOrderId = sellOrderId;
	}
	public int getSellerUserId() {
		return sellerUserId;
	}
	public void setSellerUserId(int sellerUserId) {
		this.sellerUserId = sellerUserId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSellerLocation() {
		return sellerLocation;
	}
	public void setSellerLocation(String sellerLocation) {
		this.sellerLocation = sellerLocation;
	}
	public File getImage() {
		return image;
	}
	public void setImage(File image) {
		this.image = image;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = new Date();
	}
	
}
