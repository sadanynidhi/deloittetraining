package com.example.farmerConnect.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.farmerConnect.pojo.SellProduct;

public interface SellProductRepository extends JpaRepository<SellProduct,Integer>{

}
