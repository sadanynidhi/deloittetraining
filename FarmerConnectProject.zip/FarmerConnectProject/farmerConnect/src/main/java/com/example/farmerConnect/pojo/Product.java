package com.example.farmerConnect.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Product {
	
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "BOOT_USER_SEQ")
	@SequenceGenerator(sequenceName = "customer_seq",allocationSize = 1,name = "BOOT_USER_SEQ")
	private int productId;
	private String category,name;
	private double averagePrice;
	public Product() {
		super();
	}
	public Product(String category, String name, double averagePrice) {
		super();
		this.category = category;
		this.name = name;
		this.averagePrice = averagePrice;
	}
	
	@Id
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getAveragePrice() {
		return averagePrice;
	}
	public void setAveragePrice(double averagePrice) {
		this.averagePrice = averagePrice;
	}
	
	
}
