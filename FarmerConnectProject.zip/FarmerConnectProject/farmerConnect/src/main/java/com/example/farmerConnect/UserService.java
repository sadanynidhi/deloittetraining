package com.example.farmerConnect;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserService {
	@Autowired
	UserRepository ur;
	
	public User getUser(String email) {
		return ur.findById(email).get();
	}
	
	public Boolean getId(String id) {
		return ur.findById(id).isPresent();
	}
	public void saveUser(User ct)
	{
		ur.save(ct);
	}

}
