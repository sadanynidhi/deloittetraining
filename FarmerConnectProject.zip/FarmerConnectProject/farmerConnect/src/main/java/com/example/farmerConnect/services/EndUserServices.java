package com.example.farmerConnect.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.farmerConnect.dao.EndUserDao;
import com.example.farmerConnect.pojo.EndUser;

@Service
public class EndUserServices {
	@Autowired
	EndUserDao Dao;
	List<EndUser> endUser;
	
	public List<EndUser> getData()
	{
		return Dao.listAll();
	}
	public void addEndUser(EndUser eu)
	{
		Dao.saveEndUser(eu);
	}
	
	public EndUser findEndUser(int id)
	{
		
		EndUser endUser1 = Dao.getId(id);
		return endUser1;
	}
	
	public List<EndUser> deleteEndUser(int id)
	{
		Dao.deleteEndUser(id);
		endUser=getData();
		return endUser;
	}
	
	

}
