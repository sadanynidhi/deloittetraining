package com.example.farmerConnect;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface sellproductrepository extends JpaRepository<sellproduct,Integer>{
	
	List<sellproduct> findByemail(String email);
	sellproduct findBysellid(int sellid);
	List<sellproduct> findByname(String name);

}
