package com.example.farmerConnect.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class EndUser {
	
	
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "BOOT_USER_SEQ")
	@SequenceGenerator(sequenceName = "customer_seq",allocationSize = 1,name = "BOOT_USER_SEQ")
	private int userId;
	private String name,email,password,contact,city,address;

	public EndUser() {
		super();
	}
	
	public EndUser(String name, String email, String password, String contact, String city, String address) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.contact = contact;
		this.city = city;
		this.address = address;
	}
	
	@Id
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
		

}
