$(document).ready(function () {
    //Initialize tooltips
    $('.nav-tabs > li a[title]').tooltip();
    
    //Wizard
    $('a[data-toggle="tab"]').on('show.bs.tab', function (e) {

        var $target = $(e.target);
    
        if ($target.parent().hasClass('disabled')) {
            return false;
        }
    });

    $(".next-step").click(function (e) {

        var $active = $('.wizard .nav-tabs li.active');
        $active.next().removeClass('disabled');
        nextTab($active);

    });
    $(".prev-step").click(function (e) {

        var $active = $('.wizard .nav-tabs li.active');
        prevTab($active);

    });
});

function nextTab(elem) {
    $(elem).next().find('a[data-toggle="tab"]').click();
}
function prevTab(elem) {
    $(elem).prev().find('a[data-toggle="tab"]').click();
}

 function dynamicdropdown(listindex)
            {
                document.getElementById("subcategory").length = 0;
                switch (listindex)
                {
                    case "Grains" :
                        document.getElementById("subcategory").options[0]=new Option("Please select Product","");
                        document.getElementById("subcategory").options[1]=new Option("Rice","Rice");
                        document.getElementById("subcategory").options[2]=new Option("Wheat","Wheat");
                        document.getElementById("subcategory").options[3]=new Option("Oats","Oats");
                        document.getElementById("subcategory").options[4]=new Option("Bulgur","Bulgur");
                        document.getElementById("subcategory").options[5]=new Option("Freekeh","Freekeh");
                        break;
                    
                    case "Flowers" :
                        document.getElementById("subcategory").options[0]=new Option("Please select Product","");
                        document.getElementById("subcategory").options[1]=new Option("Lotus","Lotus");
                        document.getElementById("subcategory").options[2]=new Option("Rose","Rose");
                        document.getElementById("subcategory").options[3]=new Option("Sunflower","Sunflower");
                        break;
                    case "Fruits" :
                        document.getElementById("subcategory").options[0]=new Option("Please select Product","");
                        document.getElementById("subcategory").options[1]=new Option("Mango","Mango");
                        document.getElementById("subcategory").options[2]=new Option("Apple","Apple");
                        document.getElementById("subcategory").options[3]=new Option("Lemmon","Lemmon");
                        document.getElementById("subcategory").options[4]=new Option("Watermelon","Watermelon");
                        break;
                    case "Vegetables" :
                        document.getElementById("subcategory").options[0]=new Option("Please select Product","");
                        document.getElementById("subcategory").options[1]=new Option("Beans","Beans");
                        document.getElementById("subcategory").options[2]=new Option("Potato","Potato");
                        document.getElementById("subcategory").options[3]=new Option("Palak","Palak");
                        document.getElementById("subcategory").options[4]=new Option("Carrot","Carrot");
                        break;
                }
                return true;
            }