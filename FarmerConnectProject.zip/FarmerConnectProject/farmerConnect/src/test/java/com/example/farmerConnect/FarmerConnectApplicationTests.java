package com.example.farmerConnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmerConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
