package contextp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Context1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	ServletContext ctx1 = null;
	public void init(ServletConfig sc) throws ServletException
	{
		ctx1 = sc.getServletContext();
	}
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String s = request.getParameter("fname");
		ctx1.setAttribute("ob", s);
		
		out.println("your name is stored");
		out.println("<form name = 'f1' method = 'get' action = 'c2'>");
		out.println("<input type = 'submit' value = 'click' name = 'click'>");
		out.println("</form>");
		
	}

	
}
