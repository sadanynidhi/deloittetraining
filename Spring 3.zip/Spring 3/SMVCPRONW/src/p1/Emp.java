package p1;

public class Emp 
{
	String ecode,ename;

	public String getEcode() {
		return ecode;
	}

	public void setEcode(String ecode) {
		this.ecode = ecode;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public Emp(String ecode, String ename) {
		super();
		this.ecode = ecode;
		this.ename = ename;
	}

	public Emp() {
		super();
	}

}
