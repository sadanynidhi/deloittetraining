package p1;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AddController
{
	@Autowired
	EDao dao3;
	
	@RequestMapping(value="add2")
	public String addRecord1(ModelMap m)
	{
		Emp e=new Emp();
		m.addAttribute("eobj",e);
		
		return "AddJDBC";
	}
	@RequestMapping(value="save1")
	public String saveJdbcRecord(@ModelAttribute("eobj")Emp eobj1)
	{
		dao3.save(eobj1);
		return "redirect:/disDao";
		
	}

}
