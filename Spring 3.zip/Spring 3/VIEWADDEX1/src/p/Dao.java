package p;

import java.util.*;

import org.springframework.stereotype.Service;

@Service
public class Dao
{
	List<Login> l;
	
	public List getL() {
		return l;
	}
	
	public void addLogin(Login lgn) 
	{
		l.add(lgn);
	}
	
	Dao()
	{
		l=new ArrayList<Login>();
		l.add(new Login("1","abc","abc"));
		l.add(new Login("2","pqr","pqr"));
		l.add(new Login("3","qwe","tt"));
		
	}
   public  List<Login>  editData(String id) // working
   {
	   Iterator itr=l.iterator();  
		
	   Login lgi,lg1;
	   while(itr.hasNext())
	   {  
		   lgi=(Login)itr.next();  
		   if((lgi.getUserId()).equals(id))
		   {
			   System.out.println("before edit");
			   System.out.println(lgi.getUserId()+" "+lgi.getUname()+" "+lgi.getPwd());
			   lgi.setUname("elina");
		   }
			 
		}  
		return l;
   }
   public List<Login> delData(String id)
   {
	
	   
	   Iterator itr=l.iterator();  
		
	  
		while(itr.hasNext())
		{  
			 Login lgi=(Login)itr.next();  
			 if((lgi.getUserId()).equals(id))
			   {
				 System.out.println("before del");
				 System.out.println(lgi.getUserId()+" "+lgi.getUname()+" "+lgi.getPwd());
				 itr.remove();
			   }
 		}  
		  Iterator itr1=l.iterator();  
		  System.out.println("after del");	
		 while(itr1.hasNext())
			{  
				 Login lgi=(Login)itr1.next();  
				 
					 System.out.println(lgi.getUserId()+" "+lgi.getUname()+" "+lgi.getPwd());
	 		}
	   
	   return l;                                                                                                                                //now l obj removed that login obj and when getL() is called again it will give new list after deletion
   }
   
}
