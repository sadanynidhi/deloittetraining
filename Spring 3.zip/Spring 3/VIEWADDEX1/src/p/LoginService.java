package p;

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class LoginService 
{
	@Autowired
	Dao da;
	List<Login> l;
	
	public List<Login> getData()
	{
		//System.out.print("name="+da.l);
		return da.getL();
	}
	public void addLoginSer(Login lgn)
	{
		da.addLogin(lgn);
	}
	
	public List<Login> edit2(String id)
	{
		da.editData(id);
		return l;
	}
	public List<Login> del(String id)
	{
		l=da.delData(id);
		return l;
	}
	
}
