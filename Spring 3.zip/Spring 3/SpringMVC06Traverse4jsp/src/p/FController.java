package p;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class FController {
	
	@RequestMapping("/v1")
	public String show()
	{
		System.out.println("welcome to first page");
		return "second";
	}
	
	@RequestMapping("/v2")
	public String show2()
	{
		System.out.println("welcome to second page");
		return "third";
	}
	@RequestMapping("/v3")
	public String show1()
	{
		System.out.println("welcome to second page");
		return "final";
	}
}
