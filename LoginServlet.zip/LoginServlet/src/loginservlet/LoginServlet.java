package loginservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			PrintWriter out = response.getWriter();
			String s = request.getParameter("uname");
			String s1 = request.getParameter("password");
			
			if(s.equals("abc") && s1.equals("abc"))
			{
				out.println("Valid User");
				out.println("<html><body>");
				out.println("<form name = 'iii' method = 'get' action = 'pass2'>");
				out.println("Ecode<input type = 'text' value = '' name = 'ecode'>");
				out.println("Ename<input type = 'text' value = '' name = 'ename'>");
				out.println("<br><input type = 'submit' value = 'update' name = 'click'>");
				out.println("<input type = 'submit' value = 'delete' name = 'click'>");
				out.println("</form>");
				out.println("</body></html>");
			}
			else
				out.println("Invalid User");
			
		}
		catch(Exception e) {}
	}

	

}
