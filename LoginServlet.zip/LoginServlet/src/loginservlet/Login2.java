package loginservlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Login2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root";
		String password = "root";
		
		try
		{
			PrintWriter out = response.getWriter();
			String s = request.getParameter("ecode");
			String s1 = request.getParameter("ename");
			String s2 = request.getParameter("click");
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName, userName, password);
			
			
			if(s2.equals("update"))
			{
				out.println("update");
				
				PreparedStatement ps = conn.prepareStatement("update emp set ename='"+s1+"'where ecode='"+s+"'");
				
				out.print("Connected");
				
				int x = ps.executeUpdate();
				out.print(""+x+" record updated.");
			}
			else
			{
				out.println("delete");
				PreparedStatement ps = conn.prepareStatement("delete from emp where ecode='"+s+"'");
				
				out.print("Connected");
				
				int x = ps.executeUpdate();
				out.print(""+x+" record deleted.");
				
			}
		}
		catch(Exception e) {}
	}

	

}
