package p;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmpHiber {
	
	public static void main(String[] args)
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		
		Session ses = sf.openSession();
		Transaction ts = ses.beginTransaction();
		ts.begin();
		
		RegEmp re = new RegEmp();
		re.setId(7);
		re.setEname("nidhi");
		re.setBonus(50000);
		re.setSal(620000);
		ses.persist(re);
		
		ses.flush();
		ses.clear();
		
		ConEmp ce = new ConEmp();
		ce.setId(17);
		ce.setEname("abc");
		ce.setPay(4500);
		ce.setPeriod("7");
		
		ses.save(ce);
		
		ts.commit();
		ses.clear();
		
		//two tables created of 2 subclasses. 3rd table created of super class but with empty set;
		//select * from RegEmp;
		//select * from ConEmp;
		// select * from Empinh3;
		//Empty set (0.00 sec)
		
		
		
	}

}
