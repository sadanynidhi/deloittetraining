package p;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;

import java.util.Iterator;
import java.util.List;

import org.hibernate.*;
import org.hibernate.Transaction.*;

public class EmpHiber 
{
	public static void main(String[] args)
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		
		Session ses = sf.openSession();
		Transaction ts = ses.beginTransaction();
		ts.begin();
		
		Query query = ses.createQuery("from Emp1"); //create no arg constructor
		List el = query.list();
		Iterator iterator = el.iterator();
		while(iterator.hasNext())
		{
			Emp1 e1 = (Emp1) iterator.next();
			System.out.println("eid = "+e1.getId());
			System.out.println("ecode = "+e1.getEcode());
			System.out.println("ename = "+e1.getEname());
		}
		
		//hql - update
		
		/*
		 * Query q = ses.createQuery("update Emp1 set ename=:n where id=:i");
		 * q.setParameter("n", "deloitte"); q.setParameter("i", "102"); int z =
		 * q.executeUpdate();
		 * 
		 * System.out.println("z = "+z); ts.commit();
		 */
		
		//hql - delete
		
		/*
		 * String s = "102"; Query q =
		 * ses.createQuery("delete from Emp1 where id = '102'");
		 * 
		 * //Query q = ses.createQuery("delete from Emp1 where id = '"+s+"'"); //using
		 * variable //class name Emp1, not table name int z = q.executeUpdate();
		 * System.out.println("z = "+z); ts.commit();
		 */
		
		//create salary column first in database
		Query q = ses.createQuery("select sum(salary) from Emp1");
		List<Integer> list = q.list();
		System.out.println("sum = "+list.get(0));
		
		
		Query q1 = ses.createQuery("select avg(salary) from Emp1");
		List<Integer> list1 = q1.list();
		System.out.println("avg = "+list1.get(0));
		
		Query q2 = ses.createQuery("select max(salary) from Emp1");
		List<Integer> list2 = q2.list();
		System.out.println("max = "+list2.get(0));
		
		Query q3 = ses.createQuery("select count(id) from Emp1");
		List<Integer> list3 = q3.list();
		System.out.println("count = "+list3.get(0));
		
		ts.commit();
		
		
		
		
		
	}
}
