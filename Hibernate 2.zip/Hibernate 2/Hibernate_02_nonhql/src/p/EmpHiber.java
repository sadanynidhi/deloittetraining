package p;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;

import java.util.Iterator;
import java.util.List;

import org.hibernate.*;
import org.hibernate.Transaction.*;

public class EmpHiber 
{
	public static void main(String[] args)
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		
		Session ses = sf.openSession();
		Transaction ts = ses.beginTransaction();
		ts.begin();
		
		//first - insert values
		
		/*
		 * Emp1 e = new Emp1(); e.setId("102"); e.setEcode("E88"); e.setEname("gg");
		 * String eid = (String)ses.save(e); //used save instead of persist ts.commit();
		 * System.out.println("eid = "+eid);
		 */
		
		//second - retrieve values
		
		/*
		 * List e1 = ses.createQuery("from Emp1").list(); Iterator itr = e1.iterator();
		 * while(itr.hasNext()) { Emp1 em1 = (Emp1)itr.next();
		 * System.out.println("eid = "+em1.getId());
		 * System.out.println("ecode = "+em1.getEcode());
		 * System.out.println("ename = "+em1.getEname()); } ts.commit();
		 */
		
		//third - update values
		
		/*
		 * Emp1 em1 = (Emp1)ses.get(Emp1.class,"102"); em1.setEname("nidhi");
		 * ses.update(em1); ts.commit();
		 */
		
		//forth - delete
		/*
		 * Emp1 em1 = (Emp1)ses.get(Emp1.class, "102"); ses.delete(em1); ts.commit();
		 */
		
		//this is for retrieving the values from database objects
		
		/*
		 * Object o; o = ses.load(Emp1.class, new String("102")); Emp1 e = (Emp1)o;
		 * System.out.println("ename = "+e.getEname());
		 */
		
		/*
		 * Object o = ses.load(Emp1.class, new String("102")); Emp1 e = (Emp1)o;
		 * ses.delete(e); ts.commit(); System.out.println("Deleted Successfully");
		 */
		
		
		
		
	}
}
