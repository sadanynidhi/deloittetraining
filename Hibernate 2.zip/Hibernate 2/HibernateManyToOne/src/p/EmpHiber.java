package p;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.*;
import org.hibernate.Query;

public class EmpHiber
{
	void dis()
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		
		Session ses=sf.openSession();
		Transaction ts=ses.beginTransaction();
		ts.begin();
		List el = ses.createQuery("FROM Emp1").list(); 
		Iterator iterator = el.iterator();
		while(iterator.hasNext())
		{
			Emp1 e1 = (Emp1) iterator.next();
			System.out.print(" Id: " + e1.getId()); 
			System.out.print("First Name: " + e1.getEname()); 
	             
	        Address add = e1.getAddress();
	        System.out.println("\nAddress ");
	        System.out.println("\taid: " +  add.getAid());
	        System.out.println("\tCity: " + add.getCity());
	            
	     }
	     ts.commit();
	}
		
	void delete1()
	{
			
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
			
		Session ses=sf.openSession();
		Transaction ts=ses.beginTransaction();
		ts.begin();

	       Emp1 e1 =(Emp1)ses.get(Emp1.class,new String("8"));
		/* Address a=(Address)ses.get(Address.class,new String("A3"));
	    ses.delete(a);*/  //Never do this
	    ses.delete(e1);
	    ts.commit();
			
	}
		
	void update()
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
			
		Session ses=sf.openSession();
		Transaction ts=ses.beginTransaction();
		ts.begin();
		Emp1 e1 =(Emp1)ses.get(Emp1.class,new String("8"));
		e1.setEname("ketki");
			 
		ses.update(e1);
		
	    ts.commit();
	    System.out.println("successfully updated");
			
	}
	public static void main(String[] args) 
	{
		EmpHiber eh=new EmpHiber();
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		
		Session ses=sf.openSession();
		Transaction ts=ses.beginTransaction();
		ts.begin();
		
		//eh.dis();
		//eh.update();
		//eh.delete1();
		
		
		//for inserting values
		
		/*Address address1=new Address(); 
		address1.setAid("a8");
		address1.setCity("delhi"); 
	
		Emp1 e=new Emp1();
		e.setId("8");
		e.setEname("kavita");
		e.setAddress(address1);
		/////////////////ses.save(address1);/////NEVER DO THIS
		ses.save(e);
		ts.commit();
		System.out.println("success");*/
		
		//eh.dis();
		
		//eh.delete1();
		
		//eh.update();
		
		//select v.vendorName, c.customerName from Vendor v Left Join v.children c
		
		
		//left join----------------------------------------------
		Query qry= ses.createQuery("select e.ename, ad.city from Emp1 e Left Join e.address ad");

		List l = qry.list();
		Iterator it=l.iterator();

		while(it.hasNext())
		{
			Object rows[] = (Object[])it.next();
			System.out.println(rows[0]+ " -- " +rows[1]);
		}
		
	}
	

}
