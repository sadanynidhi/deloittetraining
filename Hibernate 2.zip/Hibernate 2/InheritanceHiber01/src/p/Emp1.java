package p;

public class Emp1 
{
	String ename;
	int id;
	
	public Emp1() {} //no arg constructor needed for hql

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	
}
