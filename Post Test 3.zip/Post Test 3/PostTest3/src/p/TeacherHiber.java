package p;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TeacherHiber {
	
	public static void main(String[] args)
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		
		Session ses = sf.openSession();
		Transaction ts = ses.beginTransaction();
		ts.begin();
		
		DEPT d1 = new DEPT();
		d1.setTid(1);
		d1.setTname("nidhi");
		d1.setDept("Computer Department");
		d1.setDid(100);
		d1.setDname("Computer");
		
		ses.persist(d1);
		
		ses.flush();
		ses.clear();
		
		Course c = new Course();
		c.setCid(123);
		c.setCname("Java");
		c.setDept("Computer Department");
		c.setTid(2);
		c.setTname("xyz");
		
		ses.save(c);
		
		ts.commit();
		ses.clear();
		
	}

}
