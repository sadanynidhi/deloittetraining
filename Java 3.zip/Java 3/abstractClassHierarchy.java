abstract class abstractClass
{
	abstract void show();
}
class subClass extends abstractClass
{
	void show()
	{
		System.out.println("Sub class");
	}
	
}
class grand_child extends subClass
{
	/*void show()
	{
		System.out.println("grand child");
	}*/
	public static void main(String args[])
	{
		grand_child b1 = new grand_child();
		b1.show();
	}
}