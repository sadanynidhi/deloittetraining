interface interfaceDemo
{
	void show();
}
class int_class implements interfaceDemo
{
	public void show()
	{
		System.out.println("Class B implements Interface");
	}
	public static void main(String args[])
	{
		int_class b1 = new int_class();
		b1.show();
	}
}