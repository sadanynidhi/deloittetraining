abstract class abstractClass
{
	abstract void show();
}
class subClass extends abstractClass
{
	void show()
	{
		System.out.println("Sub class");
	}
	public static void main(String args[])
	{
		subClass b1 = new subClass();
		b1.show();
	}
}