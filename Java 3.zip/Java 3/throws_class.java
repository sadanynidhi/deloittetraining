class throws_class
{
	int x,y,z;
	void div() throws IllegalArgumentException, InterruptedException 
	{	
		Thread.sleep(-1); 
		
		
	}
	public static void main(String args[])
	{
		throws_class b1 = new throws_class();
		try
		{
			b1.div();
		}
		catch(IllegalArgumentException e)
		{
			System.out.println("Exception is IllegalArgumentException");
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		finally
		{
			System.out.println("finally");
		}
		
	}
}