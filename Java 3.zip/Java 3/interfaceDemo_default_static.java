interface interface1
{
	void show();
	default void display()
	{
		System.out.println("Default method display");
	}
}
interface interface2
{
	void dis();
	static void displaystatic()
	{
		System.out.println("Static method display");
	}
}
class parent_class
{
	void add()
	{

	}
}
class interfaceDemo_default_static extends parent_class implements interface1, interface2
{
	public void show()
	{
		System.out.println("Class B implements Interface 1");
	}
	public void dis()
	{
		System.out.println("Class B implements Interface 2");
	}
	
	public static void main(String args[])
	{
		interfaceDemo_default_static b1 = new interfaceDemo_default_static();
		b1.show();
		b1.display();
		b1.dis();
		interface2.displaystatic();
		b1.add();
	}
}