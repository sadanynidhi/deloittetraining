interface interface1
{
	void show();
}
interface interface2
{
	void dis();
}
class parent_class
{
	void add()
	{

	}
}
class int_class extends parent_class implements interface1, interface2
{
	public void show()
	{
		System.out.println("Class B implements Interface 1");
	}
	public void dis()
	{
		System.out.println("Class B implements Interface 2");
	}
	
	public static void main(String args[])
	{
		int_class b1 = new int_class();
		b1.show();
		b1.dis();
		b1.add();
	}
}