class try_class
{
	int x,y,z;
	void div()
	{	
		try
		{	z=0;
			x=y/z;
			System.out.println(x);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Division by zero not allowed");
		}
	}
	public static void main(String args[])
	{
		try_class b1 = new try_class();
		b1.div();
	}
}