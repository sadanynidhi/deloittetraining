package collection;
import java.util.*;

class Emp1 implements Comparable<Emp1>{
	int id;
	String name;
	Emp1(int id, String name)
	{
		this.id = id;
		this.name = name;
	}
	
	public int compareTo(Emp1 e1) {
		// TODO Auto-generated method stub
		return name.compareTo(e1.name);
	}
	
	public String toString()
	{
		return id+" "+name;
	}
}


public class CollectComparable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Emp1 e1 = new Emp1(1,"a");
		Emp1 e2 = new Emp1(8,"dza");
		
		List<Emp1> s1 = new ArrayList<Emp1>();
		s1.add(e1);
		s1.add(e2);
		
		Collections.sort(s1);
		System.out.println(s1);


	}

}
