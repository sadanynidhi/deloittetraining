package collection;
import java.util.*;

class Books{
	int id;
	String name,author,publisher;
	int quantity;
	
	public Books(int id, String name, String author, String publisher, int quantity)
	{
		this.id = id;
		this.name = name;
		this.author = author;
		this.publisher = publisher;
		this.quantity = quantity;
	}
}

public class HashMapEg2 {
	
	static void hashMapEg2()
	{
		Map<Integer,Books> hm = new HashMap<Integer,Books>();
		Scanner sc = new Scanner(System.in);
		//Scanner in=new Scanner(System.in);
		System.out.println("How many entries do you want to enter? ");
		int n=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter book id");
			int id = sc.nextInt();
			System.out.println("Enter book Name");
			String name = sc.next();
			System.out.println("Enter book author");
			String author = sc.next();
			System.out.println("Enter book publisher");
			String publisher = sc.next();
			System.out.println("Enter book quantity");
			int quantity = sc.nextInt();
			Books b = new Books(id,name,author,publisher,quantity);
			hm.put(1,b);
		}
		
		
		
		for(Map.Entry<Integer,Books>entry1:hm.entrySet())
		{
			int key = entry1.getKey();
			Books b = entry1.getValue();
			
			System.out.println(key+" Details: ");
			System.out.println(b.id+" "+b.name+" "+b.author+" "+b.publisher+" "+b.quantity);
		}
		
		
		
		
		Set set = hm.entrySet();
		
		Iterator itr = set.iterator();
		System.out.println("With Iterator");
		
		while(itr.hasNext())
		{
			Map.Entry me = (Map.Entry)itr.next();
			Book bb = (Book)me.getValue();
			
			System.out.println(me.getKey());
			System.out.println(bb.id+" "+bb.name+" "+bb.author+" "+bb.publisher+" "+bb.quantity);
		}
		System.out.println("End");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		hashMapEg2();
		
	}

}
