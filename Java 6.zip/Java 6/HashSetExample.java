package collection;

import java.util.HashSet;
import java.util.Scanner;

class Book {
	int id;
	String name, author, publisher;
	int quantity;
	
	public Book(int id, String name, String author, String publisher, int quantity)
	{
		this.id = id;
		this.name = name;
		this.author = author;
		this.publisher = publisher;
		this.quantity = quantity;
	}
}

class HashSetExample
{
	
	void show()
	{
		HashSet<Book> set1 = new HashSet<Book>();
		
		System.out.println("How many entries of books do you want to enter? ");
		Scanner in = new Scanner(System.in);
		
		int n = in.nextInt();
		
		
		for(int i=0;i<n;i++)
		{
			System.out.println("Id");
			int id1 =in.nextInt();
			in.nextLine();
			
			System.out.println("Enter Name of book");
			String name1 =in.nextLine();
			
			
			
			System.out.println("Enter Author");
			String author1 = in.nextLine();
			
			
			System.out.println("Enter publisher");
			String publisher1 = in.nextLine();
			
			System.out.println("Enter quanity");
			int quantity1 = in.nextInt();
			
			
			Book b = new Book(id1, name1, author1, publisher1, quantity1);
			
			set1.add(b);
			
		
		}
		
		for(Book b1 : set1)
		{
			System.out.println(b1.id + " " + b1.name + " " + b1.author + " " + b1.publisher + " " + b1.quantity);
		}
		in.close();
		
		
	}
	public static void main(String args[])
	{
		HashSetExample h = new HashSetExample();
		h.show();
	}
}
