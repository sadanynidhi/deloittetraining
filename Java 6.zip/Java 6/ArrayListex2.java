package collection;

import java.util.*;
class Student{
	int rollno,age;
	String name;
	public Student(int rollno,String name, int age) {
		super();
		this.rollno = rollno;
		this.age = age;
		this.name = name;
	}	
}

public class ArrayListex2 
{
	static void AddStudent() 
	{
		Scanner in=new Scanner(System.in);
		ArrayList<Student> lab2=new ArrayList<Student>();
		System.out.println("How many entries do you want to enter? ");
		int n=in.nextInt();
		
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter Roll No");
			int R1=in.nextInt();
			System.out.println("Enter Name");
			String N1=in.next();
			System.out.println("Enter Age");
			int A1=in.nextInt();
			Student s=new Student(R1,N1,A1);
			lab2.add(s);
		}
		
		Iterator itr=lab2.iterator();
		System.out.println("Before Deletion");
		
		while(itr.hasNext())
		{
			Student st=(Student) itr.next();
			System.out.println("Roll no: "+st.rollno+" "+"Name :"+st.name+" "+"Age: "+st.age);
			if(st.rollno>3)
			{itr.remove();}
			if(st.name.equals("Rajas"))
				st.name="Nidhi";
		}
		System.out.println("After Update & Deletion");
		Iterator itr1=lab2.iterator();
		
		while(itr1.hasNext())
		{
			Student st=(Student) itr1.next();
			System.out.println("Roll no: "+st.rollno+" "+"Name :"+st.name+" "+"Age: "+st.age);
		}
		
	}
	

	public static void main(String[] args) {
	
		AddStudent();
	}

}
