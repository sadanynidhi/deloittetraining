package collection;
import java.util.*;

class Emp{
	int id;
	String name;
	Emp(int id, String name)
	{
		this.id = id;
		this.name = name;
	}
	
	public String toString()
	{
		return id+" "+name;
	}
}

class Mycomparator implements Comparator<Emp>{

	@Override
	public int compare(Emp e1, Emp e2) {
		// TODO Auto-generated method stub
		return e1.name.compareTo(e2.name);
	}
}

public class CollectCompare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Emp e1 = new Emp(1,"a");
		Emp e2 = new Emp(8,"dza");
		Emp e3 = new Emp(4,"sdaj");
		
		List<Emp> s1 = new ArrayList<Emp>();
		s1.add(e1);
		s1.add(e2);
		s1.add(e3);
		Collections.sort(s1, new Mycomparator());
		System.out.println(s1);

	}

}
