package pha;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;

@Entity
@Table(name = "EmpA")
public class Emp1 {
	@Id
	String id;
	
	@Column(name = "ecode")
	String ecode;
	
	@Column(name = "ename")
	String ename;
	
	public Emp1()
	{
		
	}

	public String getId() {
		return id;
	}

	public String getEcode() {
		return ecode;
	}

	public String getEname() {
		return ename;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setEcode(String ecode) {
		this.ecode = ecode;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}
	
	
}
