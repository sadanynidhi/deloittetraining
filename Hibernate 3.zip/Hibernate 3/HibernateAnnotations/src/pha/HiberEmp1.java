package pha;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

public class HiberEmp1 {
	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf=new AnnotationConfiguration().addAnnotatedClass(Emp1.class).configure().buildSessionFactory();
		
		Session sess=sf.openSession();
		Transaction ts=sess.beginTransaction();
		ts.begin();
		
		Emp1 e1 = new Emp1();
		e1.setId("1");
		e1.setEname("aaaa");
		e1.setEcode("7689");
		
		sess.persist(e1);
		System.out.println("Success");
		ts.commit();
	}
}
