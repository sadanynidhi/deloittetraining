package loginservletproject;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class LoginProject extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root";
		String password = "root";
		try 
		{
			PrintWriter out = response.getWriter();
			
			
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName, userName, password);
				
			Statement sm=conn.createStatement();
			ResultSet rs=sm.executeQuery("select * from login");
				
			boolean check=false;
				while(rs.next())
				{
					String f=rs.getString(1);
					String f1=rs.getString(2);
					String s = request.getParameter("uname");
					String s1 = request.getParameter("password");
					
					if(s.equals(f)&&s1.equals(f1))
					{
						out.println("Valid User");
						out.println("Welcome "+s);
						
						Cookie cr = new Cookie("user",s);
						response.addCookie(cr);
						
						out.print("<html><body>");
						out.print("<form method='get' action='pass1'>");
						out.print("ECODE:<input type='text' name='ecode'>");
						out.print("<br><br>");
						out.print("ENAME:<input type='text' name='ename'>");
						out.print("<br><br>");
						
						out.print("<input type='submit' value ='Display' name='click'>");
						out.print("<input type='submit' value ='Update' name='click'>");
						out.print("<input type='submit' value ='Delete' name='click'>");
						out.print("</html></body>");
						check=true;
					}
					
				}
				if(!check)
				out.print("Invalid User");
			
		}catch(Exception e) {}
	}
	

}
