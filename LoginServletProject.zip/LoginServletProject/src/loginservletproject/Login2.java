package loginservletproject;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Login2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root";
		String password = "root";
		
		
		
		try
		{
			PrintWriter out = response.getWriter();
			String c = null;
			
			Cookie cr[] = request.getCookies();
			if(cr!=null)
			{
				for(int i =0; i<cr.length;i++)
				{
					c=cr[i].getValue();
					
					out.println("Welcome "+c);
				}
			}
			else
			{
				out.println("no cookie found");
			}
			
			String s = request.getParameter("ecode");
			String s1 = request.getParameter("ename");
			String s2 = request.getParameter("click");
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url+dbName, userName, password);
			
			
			if(s2.equals("Update"))
			{
				out.println("update");
				
				PreparedStatement ps = conn.prepareStatement("update emp set ename='"+s1+"'where ecode='"+s+"'");
				
				out.println("Connected");
				
				int x = ps.executeUpdate();
				out.println(""+x+" record updated.");
			}
			else if(s2.equals("Delete"))
			{
				out.println("delete");
				PreparedStatement ps = conn.prepareStatement("delete from emp where ecode='"+s+"'");
				
				out.print("Connected");
				
				int x = ps.executeUpdate();
				out.print(""+x+" record deleted.");
				
			}
			else
			{
				out.println("display");
				Statement sm = conn.createStatement();
				ResultSet rs = sm.executeQuery("select * from emp");
				
				out.print("Connected");
				
				out.print("<table border = 1 bgcolor = lightblue>");
				out.print("<th>ECODE</th><th> ENAME</th>");
				while(rs.next())
				{
					String f = rs.getString(1);
					String f1 = rs.getString(2);
					out.print("ename ="+f1);
					out.print("<tr><td>"+f+"</td><td>"+f1+"</td></tr>");
					
				}
				out.println("</table>");
			}
		}
		catch(Exception e) {}
	}
	
	
}
