package sessionproject;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String un = request.getParameter("uname");
		String pwd = request.getParameter("password");
		HttpSession ses = request.getSession(true);
		if(un.equals("abc"))
		{
			out.println("Welcome " + un);
			
			ses.setAttribute("user", un);
			out.println("<br>login page id = "+ses.getId());
			out.println("<br>session id");
			out.println(ses.getId());
			
			out.println("<br>session id");
			out.println(ses.getId());
			out.println("creation time");
			out.println(new Date(ses.getCreationTime()));
			out.println("<br>Last accesss time:");
			out.println(new Date(ses.getLastAccessedTime()));
			out.println("<br>Maximum inactive interval(seconds)");
			out.println(ses.getMaxInactiveInterval());
			out.println("<br><a href='/SessionProject/2'>visit</a>");
		}
		else
		{
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			out.println("<font color = red>Either user name or password is wrong</font>");
			rd.include(request, response);
		}
	}

	

}
