package posttest2;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Employee extends HttpServlet {
	String fname;
	String lname;
	String addrress;
	String empid;
	
    

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "db1";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root";
		String password = "root";
		
		try
		{
			PrintWriter out = response.getWriter();
			
			
			String s = request.getParameter("fname");
			String s1 = request.getParameter("lname");
			String s2 = request.getParameter("address"); 
			
			
			
					
			
			
			try 
			{
				Class.forName(driver);
				conn = DriverManager.getConnection(url+dbName, userName, password);
				Statement sm1 = conn.createStatement();
				ResultSet rs1 = sm1.executeQuery("select * from employee");
				int count =1;
				while(rs1.next())
				{
					count++;
				}
				out.print("no of rows:"+count);
				
				String s3 = s.substring(0,2)+s1.substring(0, 2)+count;
				
				PreparedStatement ps = conn.prepareStatement("insert into employee values('"+s+"','"+s1+"','"+s3+"','"+s2+"')");
				
				out.print("Connected");
				
				int x = ps.executeUpdate();
				out.print(""+x+" record inserted");
				
				Statement sm = conn.createStatement();
				ResultSet rs = sm.executeQuery("select * from employee");
				
				
				out.print("<table border = 1 bgcolor = lightblue>");
				out.print("<th>fname</th><th> lname</th><th> empid</th><th> address</th>");
				while(rs.next())
				{
					String f = rs.getString(1);
					String f1 = rs.getString(2);
					String f2 = rs.getString(3);
					String f3 = rs.getString(4);
					out.print("ename ="+f1);
					out.print("<tr><td>"+f+"</td><td>"+f1+"</td><td>"+f2+"</td><td>"+f3+"</td></tr>");
					
				}
				out.println("</table>");
				conn.close();
				out.print("Disconnected from database");
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		
		catch(IOException e)
		{
			System.out.println(e);
		}
	}


	
	
}
